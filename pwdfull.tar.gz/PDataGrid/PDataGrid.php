<?php
/**
 * ContatosList Listing
 * @author  <your name here>
 */
class PDataGrid extends TElement
{
   
   private $panel;
   
    
    /**
     * Class constructor
     * Creates the page, the form and the listing
     */
    public function __construct()
    {
    
}
?>


<?php

require_once('PMaps.php');
    $mapa = new PMaps();
$mapa->makeMap();
?>

